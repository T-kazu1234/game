/*
Viz.js {{VIZ_VERSION}} (Graphviz {{GRAPHVIZ_VERSION}}, Expat {{EXPAT_VERSION}}, Emscripten {{EMSCRIPTEN_VERSION}})
*/
(function(global) {
var Module = function(Module) {
  Module = Module || {};
